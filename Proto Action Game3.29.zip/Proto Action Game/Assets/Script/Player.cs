﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class Player : Player_Paramete
{
    private GameObject  asteroid,           //アステロイドのオブジェクトの変数
                        col_Obj;            //攻撃時に当たった敵のオブジェクト
    private bool        isJump,             //ジャンプのフラグ
                        isAvoid,            //回避のフラグ
                        isAttack;           //攻撃のフラグ
    private Rigidbody2D p_rigidbody;
    private KeyCode     key;                //キーの変数
    private void Start()
    {
        //初期化
        Initialize();

        p_rigidbody = this.gameObject.GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        //FixedUpdateでは挙動がよくない
        //キーが押されたとき
        if (Input.anyKeyDown)
        {
            foreach (KeyCode key in Enum.GetValues(typeof(KeyCode)))
            {
                if (Input.GetKeyDown(key))
                {
                    KeyDiscrimination(key);
                    break;
                }
            } 
        }

        if (isJump)
        {
            isJump = false;
            return;
        }
    }

    /// <summary>
    /// 値の初期化をする
    /// </summary>
    private void Initialize()
    {
        //変数の初期化
        p_Hp = p_MaxHp;
        p_jumpCnt = p_jumpCntMax;

        //フラグの初期化
        isJump = false;
        isAttack = false;
    }

    /// <summary>
    /// プレイヤーの移動
    /// </summary>
    private void IMove()
    {
        // 右・左の動き
        float x = Input.GetAxisRaw("Horizontal");

        // 移動する向きを求める
        Vector2 direction = new Vector2(x, 0).normalized;

        // 移動する向きとスピードを代入する
        GetComponent<Rigidbody2D>().velocity = direction * p_Speed;
    }

    /// <summary>
    /// 通常攻撃
    /// </summary>
    private void Attack()
    {
        //フラグが立っていなくて敵のオブジェクトに当たっているとき
        if (!(isAttack&& col_Obj)) return;
    }

    /// <summary>
    /// アステロイドを打つ
    /// </summary>
    private void AstFire()
    {
        Asteroid asteroid_sc = asteroid.GetComponent<Asteroid>();
        //アステロイドを使う
        asteroid_sc.Shooting();
    }

    /// <summary>
    /// ジャンプ
    /// </summary>
    private void IJump()
    {
        //ジャンプ回数によって何回かジャンプできるようにする
        if (p_jumpCnt>0&&!isJump)
        {
            p_jumpCnt--;
            Debug.Log("ジャンプ");
            //ここにジャンプの処理を加える
            p_rigidbody.AddForce(transform.up*jump_distance);
        }
        else 
        {
            isJump = true;
            return;
        }
    }

    /// <summary>
    /// ジャンプできるようにする
    /// </summary>
    private void JumpReset()
    {
        isJump = false;
        p_jumpCnt = p_jumpCntMax;
    }
    
    /// <summary>
    /// 回避
    /// </summary>
    private void Avoid()
    {
        if (isAvoid) return;
        isAvoid = true;
        //任意の秒数で回避できるようにする
        Invoke("AvoidRecivery", avoid_Time);
    }

    /// <summary>
    /// 回避した後に呼び出される
    /// </summary>
    private void AvoidRecivery()
    {
        //回避できるようにする
        isAvoid = false;
    }
    

    /// <summary>
    /// 攻撃を受けた時
    /// </summary>
    public void Difence(int damage)
    {
        //ダメージがHPを超えていた時
        if (damage > p_Hp)
        {
            //死んだ
            DeadMe();
            return;
        }
        else
        {
            //HPを減らす
            p_Hp -= damage;
            return;
        }
    }

    /// <summary>
    /// 体力が0になった時
    /// </summary>
    private void DeadMe()
    {
        //残機があればその場所から復活する予定
        p_StockCnt--;
        //残機がなくなった時
        if (p_StockCnt>0) return;
        //自分を非表示にする
        this.gameObject.SetActive(false);
        //値の初期化
        Initialize();
    }
    

    /// <summary>
    /// 他のオブジェクトに当たった時の処理
    /// </summary>
    /// <param name="collision">当たったオブジェクト</param>
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //当たったオブジェクトのタグによって処理を変える
        switch (collision.tag)
        {
            //敵の時
            case "enemy":
                //敵を格納する
                col_Obj = collision.gameObject;
                break;
            case "ground":
                JumpReset();
                
                break;
            //何もないとき処理はしない
            default:
                break;

        }
        Debug.Log("ジャンプできる");
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        //当たったオブジェクトのタグによって処理を変える
        switch (collision.tag)
        {
            //敵の時
            case "enemy":
                //敵を格納する
                col_Obj = null;
                break;
            //何もないとき処理はしない
            default:
                break;

        }
    }


    private void KeyDiscrimination(KeyCode keycode)
    {
        switch (keycode)
        {
            //ジャンプ
            case KeyCode.LeftShift:
                IJump();
                break;
            case KeyCode.Space:
                break;
            default:
                break;
        }
    }
}
