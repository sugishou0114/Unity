﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : Asteroid_Paramete
{
    private void OnEnable()
    {
        //表示されているとき
        if (!this.gameObject.activeSelf) return;
        //任意の秒数で自分を消す
        Invoke("DleteMe",ast_LifeTime);
    }
    /// <summary>
    /// プレイヤーから打つときに呼び出される  
    /// </summary>
    public void Shooting()
    {
        //自分の表示
        this.gameObject.SetActive(true);
    }

    private void FixedUpdate()
    {
        //移動
        IMove();
    }

    /// <summary>
    /// 非表示にする
    /// </summary>
    private void DleteMe()
    {
        //非表示にする
        this.gameObject.SetActive(false);
    }

    /// <summary>
    /// 移動(向いている方向にまっすぐ進む)
    /// </summary>
    private void IMove()
    {
        this.transform.position = transform.forward * ast_Speed * Time.deltaTime;
    }
    
    

    /// <summary>
    /// 他のオブジェクトに当たった時の処理
    /// </summary>
    /// <param name="collision">当たったオブジェクト</param>
    private void OnTriggerEnter2D(Collider2D collision)
    {
        
    }

}
