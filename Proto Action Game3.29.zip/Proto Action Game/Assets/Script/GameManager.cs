﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    private bool isGameEnd;                 //ゲームが終了した時のフラグ
    [SerializeField]
    private string gameOverScene;           //ゲームオーバーのシーン名

    private void Start()
    {
        //フラグの初期化
        isGameEnd = false;
    }

    private void FixedUpdate()
    {
        if (!(isGameEnd&Input.anyKey)) return;
        //ゲームオーバーシーンに移動
        SceneManager.LoadSceneAsync(gameOverScene);
    }

    /// <summary>
    /// 終了した時に呼び出される
    /// </summary>
    public void GameFinish()
    {
        //フラグを立てる
        isGameEnd = true;
    }
}
