﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Paramete : MonoBehaviour
{
    protected int e_Attack,                 //敵の攻撃力
                  e_Difence,                //敵の防御力
                  e_
                  e_Speed;                  //敵のスピード
}
