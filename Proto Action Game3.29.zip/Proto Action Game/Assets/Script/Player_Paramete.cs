﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Paramete: MonoBehaviour
{
    //プレイヤーのステータス
    [SerializeField]
    protected float p_Speed,                //プレイヤーのスピード
                    attack_Time,            //アタックのインターバル
                    jump_distance,          //ジャンプの距離
                    avoid_Time;             //回避のインターバル
    [SerializeField]
    protected int   p_Atack,                //プレイヤーの攻撃力
                    p_defense,              //プレイヤーの防御力
                    p_Masic,                //プレイヤーの魔力
                    p_jumpCntMax,           //プレイヤーのジャンプ最大回数
                    p_MaxHp,                //プレイヤーの最大HP
                    p_StockCnt,             //プレイヤーの残機
                    avoidance_Cnt;          //連続回避回数
    protected int   p_Hp,                   //プレイヤーのHP
                    p_jumpCnt;              //プレイヤーのジャンプの回数     
    private string attack_Key,              //攻撃のキー
                   avoid_Key,               //回避のキー
                   asteroid_Key;            //アステロイドのキー
                   
                   

}
