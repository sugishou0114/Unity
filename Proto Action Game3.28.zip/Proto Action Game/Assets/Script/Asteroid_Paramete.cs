﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid_Paramete : MonoBehaviour
{
    [SerializeField]
    protected int   ast_Power,              //アステロイドのパワー
                    ast_Speed,              //アステロイドの速さ
                    ast_Cnt,                //アステロイドの数
                    ast_LifeTime,           //
                    Max_Point;              //最大値の数
    protected float intervalTime;           //打った後のインターバルの時間
    [SerializeField]
    protected GameObject asteroidObj;       //生成するアステロイドのオブジェクト


    private void Awake()
    {
    　  //マックスの値が超えていたら
        if (ast_Cnt+ast_Power+ast_Speed> Max_Point)
        {
            ExclusiveCheck();
        }
    }

    /// <summary>
    /// インターバルの時間の設定
    /// </summary>
    private void SetInterval()
    {

    }

    /// <summary>
    /// 値の合計が最大値を超えないようにする
    /// </summary>
    private void ExclusiveCheck()
    {
        
    }

}
