﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Paramete: MonoBehaviour
{
    //プレイヤーのステータス
    [SerializeField]
    protected float p_Speed,                //プレイヤーのスピード
                    attack_Time,            //アタックのインターバル
                    avoid_Time;             //回避のインターバル
    [SerializeField]
    protected int   p_Atack,                //プレイヤーの攻撃力
                    p_defense,              //プレイヤーの防御力
                    p_Masic,                //プレイヤーの魔力
                    p_jumpCnt,              //プレイヤーのジャンプ回数
                    p_MaxHp,                //プレイヤーの最大HP
                    p_StockCnt,             //プレイヤーの残機
                    avoidance_Cnt;          //連続回避回数
    protected int   p_Hp;                   //プレイヤーのHP

    private string attack_Key,
                   avoid_Key,
                   asteroid_Key;
                   
                   

}
